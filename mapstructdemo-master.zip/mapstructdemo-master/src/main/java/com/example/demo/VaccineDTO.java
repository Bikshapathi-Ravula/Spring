package com.example.demo;

public class VaccineDTO {

	private String name;
	
	private String company;
	
	private String totalno;
	
	private String totalDoses;
	
	private String dosageGap;
	
	private String country;
	
	private String state;
	
	private String city;
	
	

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getTotalno() {
		return totalno;
	}

	public void setTotalno(String totalno) {
		this.totalno = totalno;
	}

	public String getTotalDoses() {
		return totalDoses;
	}

	public void setTotalDoses(String totalDoses) {
		this.totalDoses = totalDoses;
	}

	public String getDosageGap() {
		return dosageGap;
	}

	public void setDosageGap(String dosageGap) {
		this.dosageGap = dosageGap;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	
	
}
