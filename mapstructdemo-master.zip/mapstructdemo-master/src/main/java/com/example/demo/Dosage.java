package com.example.demo;

public class Dosage {

	
	private int noOfDosesRequired;
	
	private int gapBetweenDoses;

	public int getNoOfDosesRequired() {
		return noOfDosesRequired;
	}

	public void setNoOfDosesRequired(int noOfDosesRequired) {
		this.noOfDosesRequired = noOfDosesRequired;
	}

	public int getGapBetweenDoses() {
		return gapBetweenDoses;
	}

	public void setGapBetweenDoses(int gapBetweenDoses) {
		this.gapBetweenDoses = gapBetweenDoses;
	}
	
	
}
