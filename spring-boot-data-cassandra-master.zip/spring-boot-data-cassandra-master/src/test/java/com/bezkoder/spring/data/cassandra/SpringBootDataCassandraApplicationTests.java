package com.bezkoder.spring.data.cassandra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataCassandraApplicationTests {

	@Test
	void contextLoads() {
	}

}
